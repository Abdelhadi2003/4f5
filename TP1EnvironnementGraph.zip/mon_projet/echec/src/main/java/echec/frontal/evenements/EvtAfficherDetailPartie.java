package echec.frontal.evenements;

import ca.ntro.app.frontend.events.EventNtro;

public class EvtAfficherDetailPartie extends EventNtro{

}
